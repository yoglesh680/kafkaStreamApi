package com.example.kafkaStreamAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaStreamApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
